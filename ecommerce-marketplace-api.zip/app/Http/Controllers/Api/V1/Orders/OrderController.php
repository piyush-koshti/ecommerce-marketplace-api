<?php

namespace App\Http\Controllers\Api\V1\Orders;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\SellerOrder;
use App\Models\StockReservation;
use App\Services\Inventory\StockReservationService;
use App\Support\Api\ApiResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;

class OrderController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        return ApiResponse::success(Order::where('user_id', $request->user()->id)->with('sellerOrders.items')->latest()->paginate(20));
    }

    public function show(Request $request, Order $order): JsonResponse
    {
        abort_unless((int) $order->user_id === (int) $request->user()->id, 404);

        return ApiResponse::success($order->load(['sellerOrders.items', 'histories']));
    }

    public function sellerIndex(Request $request, int $sellerAccount): JsonResponse
    {
        $this->assertSellerMember($request, $sellerAccount);

        return ApiResponse::success(SellerOrder::where('seller_account_id', $sellerAccount)->with(['items', 'order'])->latest()->paginate(20));
    }

    public function sellerStatus(Request $request, int $sellerAccount, SellerOrder $sellerOrder, StockReservationService $reservations): JsonResponse
    {
        $this->assertSellerMember($request, $sellerAccount, true);
        abort_unless((int) $sellerOrder->seller_account_id === $sellerAccount, 404);
        $data = $request->validate([
            'status' => ['required', Rule::in(['accepted', 'processing', 'packed', 'shipped', 'delivered', 'cancelled'])],
            'reason' => ['nullable', 'string', 'max:500'],
        ]);
        $allowed = [
            'confirmed' => ['accepted', 'cancelled'],
            'accepted' => ['processing', 'cancelled'],
            'processing' => ['packed', 'cancelled'],
            'packed' => ['shipped'],
            'shipped' => ['delivered'],
            'delivered' => [],
            'cancelled' => [],
        ];
        abort_unless(in_array($data['status'], $allowed[$sellerOrder->status] ?? [], true), 409, 'Invalid seller order status transition.');
        if ($data['status'] === 'shipped') {
            abort_unless($sellerOrder->shipments()->exists(), 409, 'Create a shipment before marking this seller order shipped.');
        }
        DB::transaction(function () use ($sellerOrder, $data, $request, $reservations) {
            $from = $sellerOrder->status;
            $sellerOrder->update(['status' => $data['status']]);
            if ($data['status'] === 'shipped') {
                $sellerOrder->shipments()->update(['status' => 'in_transit', 'shipped_at' => now()]);
            }
            if ($data['status'] === 'delivered') {
                $sellerOrder->shipments()->update(['status' => 'delivered', 'delivered_at' => now()]);
            }
            if ($data['status'] === 'cancelled') {
                StockReservation::where('reference_type', 'seller_order')
                    ->where('reference_id', (string) $sellerOrder->id)
                    ->whereIn('status', ['reserved', 'committed'])->get()
                    ->each(function (StockReservation $reservation) use ($reservations, $request) {
                        if ($reservation->status === 'reserved') {
                            $reservations->release($reservation);
                        } elseif ($reservation->status === 'committed') {
                            $reservations->reverseCommitted($reservation, $request->user()->id);
                        }
                    });
            }
            $parentOrder = $sellerOrder->order;
            $parentOrder->histories()->create([
                'seller_order_id' => $sellerOrder->id, 'actor_id' => $request->user()->id,
                'from_status' => $from, 'to_status' => $data['status'], 'source' => 'seller',
                'reason' => $data['reason'] ?? null,
            ]);
            $parentOrder->load('sellerOrders');
            if ($parentOrder->sellerOrders->every(fn ($group) => $group->status === 'delivered')) {
                $previous = $parentOrder->status;
                $parentOrder->update(['status' => 'delivered']);
                $parentOrder->histories()->create([
                    'actor_id' => $request->user()->id, 'from_status' => $previous,
                    'to_status' => 'delivered', 'source' => 'system', 'reason' => 'All seller fulfilment groups delivered.',
                ]);
            } elseif ($parentOrder->sellerOrders->every(fn ($group) => $group->status === 'cancelled')) {
                $previous = $parentOrder->status;
                $parentOrder->update(['status' => 'cancelled']);
                $parentOrder->histories()->create([
                    'actor_id' => $request->user()->id, 'from_status' => $previous,
                    'to_status' => 'cancelled', 'source' => 'system', 'reason' => 'All seller fulfilment groups cancelled.',
                ]);
            }
        });

        return ApiResponse::success($sellerOrder->fresh(['items', 'order']));
    }

    public function createShipment(Request $request, int $sellerAccount, SellerOrder $sellerOrder): JsonResponse
    {
        $this->assertSellerMember($request, $sellerAccount, true);
        abort_unless((int) $sellerOrder->seller_account_id === $sellerAccount, 404);
        abort_unless($sellerOrder->status === 'packed', 409, 'Only packed seller orders can be shipped.');
        abort_if($sellerOrder->shipments()->exists(), 409, 'A shipment already exists for this seller order.');
        $data = $request->validate([
            'carrier_name' => ['required', 'string', 'max:100'],
            'tracking_number' => ['nullable', 'string', 'max:150'],
        ]);
        $shipment = DB::transaction(function () use ($sellerOrder, $data) {
            $shipment = $sellerOrder->shipments()->create([
                'carrier_name' => $data['carrier_name'],
                'tracking_number' => $data['tracking_number'] ?? null,
                'status' => 'created',
            ]);
            foreach ($sellerOrder->items as $item) {
                $shipment->items()->create(['order_item_id' => $item->id, 'quantity' => $item->quantity]);
            }

            return $shipment;
        });

        return ApiResponse::success($shipment->load('items'), 201);
    }

    private function assertSellerMember(Request $request, int $sellerId, bool $manage = false): void
    {
        abort_unless($request->user()->sellerAccounts()->where('seller_accounts.id', $sellerId)->wherePivot('status', 'active')->exists(), 404);
        abort_unless($manage ? $request->user()->hasPermissionTo('orders.manage') : ($request->user()->hasPermissionTo('orders.view') || $request->user()->hasPermissionTo('orders.manage')), 403);
    }
}
