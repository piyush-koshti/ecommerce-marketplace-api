<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class OrderStatusHistory extends Model
{
    protected $fillable = ['order_id', 'seller_order_id', 'actor_id', 'from_status', 'to_status', 'source', 'reason'];

    public function order(): BelongsTo
    {
        return $this->belongsTo(Order::class);
    }
}
